#include <iostream>
#include <stdlib.h>
using namespace std;

void main(void) {
	int n;
	cout << "Quelle taille pour le tableau ? ";
	cin >> n;
	// C++
	int *Tab = new int[n];
	// C pur
	//long long* Tab = (long long*)malloc(sizeof(long long) * n);

	for (int i = 0; i < n; i++)
	{
		Tab[i] = 2 * i;
	}

	for (int j = 0; j < n; j++)
	{
		cout << Tab[j] << "\n";
	}

	// C++
	delete[] Tab;
	// C pur
	//free(Tab);
}