/**************************************************************************
* AUTEUR :		Godefroy Borduas
* FICHIER :		fonctions.cpp
* DESCRIPTION :	Petit programme qui pr�sente l'utilisation des pointeurs
*				dans les fonctions
***************************************************************************/

#include <iostream>
#include <string>

using namespace std;

double PuissanceReference(int*, int*);
void Incrementer(float*, int);

int main(void) {
	int a = 2, b = 3;
	cout << "2^3 = " << PuissanceReference(&a, &b) << endl;
	
	float c = 5;
	cout << "Valeur de c : " << c << endl;
	Incrementer(&c, b);
	cout << "Valeur de c : " << c << endl;
	

	return 0;
}

double PuissanceReference(int *a, int *b) {
	int Resultat = 1;
	for (int i = 0; i < *b; i++)
	{
		Resultat *= *a;
	}

	return Resultat;
}
/*
*	Incr�mente la valeur de *a de b
*/
void Incrementer(float *a, int b) {
	*a += b;
}