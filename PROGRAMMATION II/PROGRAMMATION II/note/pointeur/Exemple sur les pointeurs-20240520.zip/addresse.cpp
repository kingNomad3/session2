/**************************************************************************
* AUTEUR :		Godefroy Borduas
* FICHIER :		adresse.cpp
* DESCRIPTION :	Petit programme qui pr�sente l'adresse m�moire de diff�rente
*				variable.
***************************************************************************/

#include <iostream>
#include <string>

using namespace std;

int main(void) {
	int a = 3, b = 45, c, d;
	float e;
	string f;
	long g;

	cout << "Adresse de a : " << &a << "(initialis�)" << endl;
	cout << "Adresse de b : " << &b << "(initialis�)" << endl;
	cout << "Adresse de c : " << &c << endl;
	cout << "Adresse de d : " << &d << endl;
	cout << "Adresse de e : " << &e << endl;
	cout << "Adresse de f : " << &f << endl;
	cout << "Adresse de g : " << &g << endl;

	cout << "Boucle de b " << endl;
	for (int i = 0; i < a; i++)
	{
		cout << "\t" << &b << endl;
	}

	return 0;
}