#include <iostream>
using namespace std;

struct Etudiant_e_s
{
	string Nom, Prenom;
	float Moyenne;
};

void main(void) {
	Etudiant_e_s etu = { "Borduas", "Godefroy", 42 };
	Etudiant_e_s* etuPtr = &etu;

	cout << sizeof(Etudiant_e_s) << " " << etuPtr
		<< " " << etuPtr + 1 << "\n";

	cout << (*etuPtr).Nom << " " << &(etuPtr->Prenom);
}