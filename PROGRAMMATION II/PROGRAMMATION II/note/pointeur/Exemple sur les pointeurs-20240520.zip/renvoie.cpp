/**************************************************************************
* AUTEUR :		Godefroy Borduas
* FICHIER :		renvoie.cpp
* DESCRIPTION :	Permet de tester le renvoie de deux informations
***************************************************************************/

#include <iostream>
#include <string>

using namespace std;

int* DecoupeMinute(int*);

int main(void) {
	int minutes = 90;
	cout << minutes << " minutes correspondent a ";
	cout << *DecoupeMinute(&minutes) << " heures et ";
	cout << minutes << " minutes.";

	return 0;
}

int* DecoupeMinute(int *minutes) {
	int heure = *minutes / 60;
	*minutes %= 60;

	return &heure;
}