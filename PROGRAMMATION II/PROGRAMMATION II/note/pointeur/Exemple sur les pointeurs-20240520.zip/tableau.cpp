#include <iostream>
using namespace std;

void main(void) {
	int Tab[] = { 0, 3, 6, 9, 12 };
	int* TabPtr = Tab;
	//int* TabPtr = &Tab[0];
	cout << &Tab[0] << " " << Tab << " " << TabPtr << "\n";
	for (int i = 0; i < 5; i++)
	{
		cout << "\t" << i << " " << &Tab[i] << " "
			<< TabPtr + i << "\n";
	}

	for (int i = 0; i < 5; i++)
	{
		cout << "\t" << i << " " << Tab[i] << " "
			<< *(TabPtr + i) << "\n";
	}

	cout << *(TabPtr + 5);
}