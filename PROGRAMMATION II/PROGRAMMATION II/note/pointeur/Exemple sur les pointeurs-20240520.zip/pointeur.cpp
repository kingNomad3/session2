/**************************************************************************
* AUTEUR :		Godefroy Borduas
* FICHIER :		pointeur.cpp
* DESCRIPTION :	Petit programme qui pr�sente l'affectation d'un pointeur
***************************************************************************/

#include <iostream>
#include <string>

using namespace std;

int main(void) {
	int a = 3;
	int *adrr_a = &a;

	cout << "Adresse de a : " << &a << endl;
	cout << "Valeur de *a : " << adrr_a << endl;

	cout << "Valeur de a  : " << a << endl;
	cout << "Valeur ds *a : " << *adrr_a << endl;

	*adrr_a += 5;
	cout << "Valeur de a  : " << a << endl;
	

	return 0;
}