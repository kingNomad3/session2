/**********************************************************
* AUTEUR :		Godefroy Borduas
* FICHIER :		attribution.cpp
* DESCRIPTION :	Pr�sente le fonctionne de l'allocation
*				dynamique
***********************************************************/
#include <iostream>
#include <stdlib.h>

using namespace std;

int main(void) {
	//int *SimpleAlloc = new int;
	int* SimpleAlloc = (int*)malloc(sizeof(int));

	cout << "Entree une taille pour le tableau : ";
	cin >> *SimpleAlloc;

	int taille = *SimpleAlloc;
	//int* TableauAlloc = new int[taille];
	// int Tableau[taille]; est ill�gale
	int* TableauAlloc = (int*)malloc(sizeof(int) * taille);

	cout << endl << endl << "Entree " << taille << " elements pour le tableau :" << endl;
	for (int i = 0; i < taille; i++)
	{
		cout << "\t" << "Element " << i << " : ";
		cin >> *(TableauAlloc + i);
		cout << endl;
	}

	cout << "Le tableau est donc [";
	for (int i = 0; i < taille; i++)
	{
		cout << *(TableauAlloc + i) << ", ";
	}

	cout << "]";

	// Ne pas oublier - Il faut vider la m�moire
	//delete SimpleAlloc;
	//delete[] TableauAlloc;
	free(SimpleAlloc);
	free(TableauAlloc);
}