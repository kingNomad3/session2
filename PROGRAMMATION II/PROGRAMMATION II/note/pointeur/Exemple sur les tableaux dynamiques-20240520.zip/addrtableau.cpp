/**********************************************************
* AUTEUR :		Godefroy Borduas
* FICHIER :		addrtableau.cpp
* DESCRIPTION :	Petit programme d�montrant l'arithm�tique
*				des pointeurs
***********************************************************/
#include <iostream>

using namespace std;

int main(void) {
	int A[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
	int* P = A; // �quivalent � P = &A[0]

	cout << "Indice\t\tAdresse\t\tValeur" << endl;
	for (int i = 0; i </*=*/ 10; i++)
	{
		cout << i << "   \t\t" << (P + i) << "    \t\t" << *(P + i) << endl;
	}
}