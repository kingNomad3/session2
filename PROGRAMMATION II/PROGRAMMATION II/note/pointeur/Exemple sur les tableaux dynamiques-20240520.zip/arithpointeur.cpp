/**********************************************************
* AUTEUR :		Godefroy Borduas
* FICHIER :		arithmpointeur.cpp
* DESCRIPTION :	Petit programme d�montrant l'arithm�tique
*				des pointeurs
***********************************************************/
#include <iostream>

using namespace std;

int main(void) {
	int VariableEntiere = 42;
	double VariableDouble = 42.42;
	string VariableString = "42";
	short VariableChar = 42;

	int* PointeurEntier = &VariableEntiere;
	double* PointeurDouble = &VariableDouble;
	string* PointeurString = &VariableString;
	short* PointeurChar = &VariableChar;
	//void* PointeurGenerique = &VariableEntiere;

	cout << "Type\t\tAdresse\t\t\tAdr + 1\t\t\tAdr + 4" << endl;
	cout << "Int\t\t" << PointeurEntier << "\t\t" << PointeurEntier + 1 << "\t\t" << PointeurEntier + 4 << endl;
	cout << "Double\t\t" << PointeurDouble << "\t\t" << PointeurDouble + 1 << "\t\t" << PointeurDouble + 4 << endl;
	cout << "String\t\t" << PointeurString << "\t\t" << PointeurString + 1 << "\t\t" << PointeurString + 4 << endl;
	cout << "Char\t\t" << PointeurChar << "\t\t" << PointeurChar + 1 << "\t\t" << PointeurChar + 4 << endl;
	//cout << "Generique\t\t" << PointeurGenerique << "\t\t" << PointeurGenerique + 1 << "\t\t" << PointeurGenerique + 4 << endl;
}