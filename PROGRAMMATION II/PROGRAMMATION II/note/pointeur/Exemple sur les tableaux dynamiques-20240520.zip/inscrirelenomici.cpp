/**********************************************************
* AUTEUR :		Godefroy Borduas
* FICHIER :		compapointeur.cpp
* DESCRIPTION :	Petit programme permettant de comparer deux pointeurs
***********************************************************/
#include <iostream>

using namespace std;

int main(void) {
	int A[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
	int* P1 = A, * P2 = &A[5], *P3 = &A[8], *P4 = &A[5];

	int B[] = { 0, 2 };
	int* P5 = B;

	cout << "P1 - P2 : " << P1 - P2 << " (n�gatif, P1 precede P2)" << endl;
	cout << "P3 - P2 : " << P3 - P2 << " (Positif, P2 precede P3)" << endl;
	cout << "P4 - P2 : " << P4 - P2 << " (null, P2 est identique a P4)" << endl;
	cout << "P5 - P2 : " << P5 - P2 << " (ind�fini, P2 et P5 ne sont pas identique)" << endl<< endl<<endl;

	cout << "P1 < P2 : " << (P1 < P2) << " (P1 precede P2)" << endl;
	cout << "P3 > P2 : " << (P3 > P2) << " (P2 precede P3)" << endl;
	cout << "P4 == P2 : " << (P4 == P2) << " (P2 est identique a P4)" << endl;
	cout << "(P5 != P2) : " << (P5 != P2) << " (P2 et P5 ne sont pas identique)" << endl;
}