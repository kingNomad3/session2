/**********************************************************
* AUTEUR :		Godefroy Borduas
* FICHIER :		matrice.cpp
* DESCRIPTION :	Pr�sente le fonctionne un pointeur de matrice
***********************************************************/
#include <iostream>

using namespace std;

int main(void) {
	int M[3][4] = { {1, 2, 3, 4},
				{5, 6, 7, 8},
				{9, 10, 11, 12} };

	int* P = M[0];
	/*int* P = (int*)M;*/

	for (int i = 0; i < 3*4; i++)
	{
		cout << i << " : " << *(P + i) << endl;
	}
}