#include <iostream>
#include "cesar.h"

int main() {
	std::string msg = "Hello";
	std::cout << msg;
	msg = EncodageCesar(msg, 4);
	std::cout << "\t" << msg;
	msg = DecodageCesar(msg, 4);
	std::cout << "\t" << msg;
}