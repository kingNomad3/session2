#include "cesar.h"

std::string EncodageCesar(std::string Original, int Cle) {
	std::string Resultat;
	for (int i = 0; i < Original.length(); i++)
	{
		int C = (int)Original.at(i);
		if (C >= 'A' && C <= 'Z') {
			char typo = 'A';
			C -= typo; // On place la lettre A � 0
			C = ((C + Cle) % 26 + 26) % 26;
			// 1. On d�cale notre lettre selon la cl�
			// 2. On s'assure que la lettre obtenue soit entre 0 et 25 (entre A et Z)
			// 3. En C, le module d'un nombre n�gatif va �tre n�gatif. Il faut donc s'assurer que les valeurs d�caler soit entre 0 et 25
			// 4. On s'assure que le nombre est bien entre 0 et 25 gr�ce au deuxi�me modulo
			C += typo; // on replace la lettre A dans la table ASCII
			Resultat += C;
		}
		else if (C >= 'a' && C <= 'z') {
			char typo = 'a';
			C -= typo;
			C = ((C + Cle) % 26 + 26) % 26;
			C += typo;
			Resultat += C;
		}
		else
			Resultat += (char)C;
	}

	return Resultat;
}

std::string DecodageCesar(std::string Original, int Cle) {
	return EncodageCesar(Original, Cle * -1); // La cl� de d�cryptage est la valeur inverse
}

