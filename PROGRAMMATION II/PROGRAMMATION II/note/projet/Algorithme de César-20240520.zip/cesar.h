#pragma once
#include <string>

std::string EncodageCesar(std::string Original, int Cle);
std::string DecodageCesar(std::string Original, int Cle);