#include <iostream>
#include <conio.h>

using std::cout; using std::string;

struct Crayon
{
	string Couleur;
	int Diametre;
	string Force;
};

struct Noeud
{
	Crayon valeur;
	Noeud* suivant;
};

struct Liste
{
	Noeud* racine;
	size_t taille;
};

Liste* CreerListe() {
	Liste* liste = new Liste;
	liste->racine = NULL;
	liste->taille = 0;

	return liste;
}

Liste** Ajouter(Liste** liste, Crayon c) {
	Noeud* noeud = new Noeud;
	noeud->valeur = c;
	noeud->suivant = NULL;

	// Cas o� la liste est vide
	if ((*liste)->racine == NULL) {
		(*liste)->racine = noeud;
	} else {
		Noeud * node_liste = (*liste)->racine;
		while (node_liste->suivant != NULL)
			node_liste = node_liste->suivant;

		node_liste->suivant = noeud;
	}

	(*liste)->taille++;

	return liste;
}

Liste** Retirer(Liste** liste, int position) {
	if (position >= (*liste)->taille)
		return liste;

	Noeud* node = (*liste)->racine;
	for (size_t i = 0; i < position - 1; i++)
	{
		node = node->suivant;
		if (node == NULL && i < position)
			return liste;
	}

	Noeud* naretirer = node->suivant;

	node->suivant = node->suivant->suivant;
	delete naretirer;

	(*liste)->taille--;

	return liste;
}

Crayon* Rechercher(Liste **liste, int position) {
	if (position >= (*liste)->taille)
		return NULL;

	Noeud* node = (*liste)->racine;
	for (size_t i = 0; i < position; i++)
	{
		node = node->suivant;
		if (node == NULL && i < position)
			return NULL;
	}

	return &node->valeur;
}

static void LibererNoeud(Noeud* noeud) {
	if (noeud->suivant != NULL)
		LibererNoeud(noeud->suivant);
	
	delete noeud;
}

void Liberer(Liste** liste) {
	LibererNoeud((*liste)->racine);
	delete (*liste);
}

int main() {
	Liste* liste = CreerListe();
	Ajouter(&liste, { "Noir", 7, "HB" });
	Ajouter(&liste, { "Bleu", 7, "HB" });
	Retirer(&liste, 1);
	
	Crayon* exemple = Rechercher(&liste, 0);
	if (exemple != NULL) {
		cout << exemple->Couleur << ", " << exemple->Diametre << " mm, " << exemple->Force << "\n";
		exemple->Couleur = "Bleu";
	}

	Crayon* ex2 = Rechercher(&liste, 0);
	if (ex2 != NULL)
		cout << ex2->Couleur << ", " << ex2->Diametre << " mm, " << ex2->Force << "\n";

	Liberer(&liste);
}