/******************************************************
* FICHIER :     d2_q2_solution.cpp
* AUTEUR :      Godefroy Borduas
* DESCRIPTION : Solution � la question #2 du devoir 2
******************************************************/

#include <iostream>

using namespace std;

void TrierTableau(int* tableau, int taille);

int main(void) {
	int tab[] = { 4, 3,5,1,2,8,6,9, 7, 0 };
	TrierTableau(&tab[0], 10);
	for (int i = 0; i < 10; i++)
	{
		cout << tab[i] << endl;
	}
}

void TrierTableau(int* tableau, int taille) {
	for (int i = 0; i < taille - 1; i++)
	{
		for (int j = i + 1; j < taille; j++) {
			if (*(tableau + i) > *(tableau + j)) {
				int Temporaire = *(tableau + i);
				*(tableau + i) = *(tableau + j);
				*(tableau + j) = Temporaire;
			}
		}
	}
}