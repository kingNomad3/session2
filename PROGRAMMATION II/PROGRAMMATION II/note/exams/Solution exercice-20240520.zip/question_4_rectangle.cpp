#include "rectangle.h"

/// <summary>
/// Cette fonction permet de dessiner une ligne selon la largeur d�sir�e
/// et l'espace attendu devant la ligne
/// </summary>
/// <param name="Largeur">Nombre de caract�re utiliser pour g�n�r� une ligne</param>
/// <param name="Espace">Nombre de caract�re utiliser pour g�n�rer l'espace avant la ligne</param>
/// <returns>La cha�ne de caract�re qui repr�sente la ligne</returns>
std::string DessinerLigne(int Largeur, int Espace) {
	std::string Ligne;
	// G�n�ration des espaces
	for (int i = 0; i < Espace; i++)
	{
		Ligne += CARACTERE_ESPACE;
	}

	// G�n�ration de la ligne
	for (int j = 0; j < Largeur; j++)
	{
		Ligne += CARACTERE_FORME;
	}

	return Ligne;
}

/// <summary>
/// Cette fonction permet de dessiner une forme selon la hauteur (le nombre de ligne
/// d�sir�), la largeur d�sir�e d'une ligne et l'espace attendu devant la ligne
/// </summary>
/// <param name="Hauteur">Le nombre de ligne qui repr�sente la forme</param>
/// <param name="Largeur">Nombre de caract�re utiliser pour g�n�r� une ligne</param>
/// <param name="Espace">Nombre de caract�re utiliser pour g�n�rer l'espace avant la ligne</param>
/// <returns>La cha�ne de caract�re qui repr�sente la forme</returns>
std::string DessinerForme(int Hauteur, int Largeur, int Espace) {
	std::string Forme;
	// On dessine une premi�re ligne
	std::string Ligne = DessinerLigne(Largeur, Espace);

	// On recopie cette ligne dans la forme selon la hauteur d�sir�
	// La copie est plus efficace que la reg�n�ration
	for (int i = 0; i < Hauteur; i++)
	{
		Forme += Ligne + SAUT_DE_LIGNE;
	}

	return Forme;
}

/// <summary>
/// Cette fonction permet de dessiner une s�rie de ligne vide
/// </summary>
/// <param name="HauteurVide">Nombre de ligne laiss� vide</param>
/// <returns>La cha�ne de caract�re qui repr�sente les lignes vides</returns>
std::string DessinerLigneVide(int HauteurVide) {
	std::string Lignes;
	// On g�n�re les lignes vides
	for (int i = 0; i < HauteurVide; i++)
	{
		Lignes += SAUT_DE_LIGNE;
	}

	return Lignes;
}

/// <summary>
/// Cette fonction permet de dessiner, dans un fichier, une forme selon les demandes de la personne
/// utilisatrice et qui respectre les directrives de l'�nonc�.
/// </summary>
/// <param name="HauteurVide">Nombre de ligne laiss� vide avant la forme</param>
/// <param name="Hauteur">Le nombre de ligne qui repr�sente la forme</param>
/// <param name="Largeur">Nombre de caract�re utiliser pour g�n�r� une ligne</param>
/// <param name="Espace">Nombre de caract�re utiliser pour g�n�rer l'espace avant la ligne</param>
/// <returns><code>True</code> si l'�criture du fichier a r�ussi, <code>False</code> sinon</returns>
bool GenererFichier(int HauteurVide, int Hauteur, int Largeur, int Espace) {
	//return GenererFichier(DessinerFichier(HauteurVide, Hauteur, Largeur, Espace));

	std::fstream Fichier;
	Fichier.open("forme.txt", std::ios::out);
	if (Fichier.fail())
		return false;

	Fichier << DessinerLigneVide(HauteurVide);
	Fichier << DessinerForme(Hauteur, Largeur, Espace);
	Fichier.close();

	return !Fichier.fail(); // fail retourne true s'il y a eu une erreur dans le flux
}