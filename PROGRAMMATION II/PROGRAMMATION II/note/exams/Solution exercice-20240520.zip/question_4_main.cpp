#include <iostream>
#include "rectangle.h"
#include "fibonacci.h"

using std::cout;
using std::cin;
using std::endl;

int main(void) {
	int HateurVide, Hauteur, Largeur, Espace;
	cout << "Dessiner une forme :" << endl;
	cout << "\t" << "Quelle hauteur d�sirez-vous pour votre rectangle ? ";
	cin >> Hauteur;
	cout << "\t" << "Quelle largeur d�sirez-vous pour votre rectangle ? ";
	cin >> Largeur;
	cout << "\t" << "Combien de ligne vide souhaitez-vous ? ";
	cin >> HateurVide;
	cout << "\t" << "Combien d'espace souhaitez-vous avant la ligne ? ";
	cin >> Espace;

	if (GenererFichier(HateurVide, Hauteur, Largeur, Espace))
		cout << endl << "Le fichier a bien �t� g�n�r�." << endl;
	else
		cout << endl << "Le fichier n'a pas bien �t� g�n�r�." << endl;
}