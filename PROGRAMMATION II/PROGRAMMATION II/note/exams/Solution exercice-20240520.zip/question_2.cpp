/******************************************************
* AUTEUR:		Godefroy Borduas
* FICHIER:		d1q3_sln.cpp
* DESCRIPTION:	Solution de la question 3 du devoir 1
*				de la session Automne 2021 (420-C21)
*******************************************************/
#include <iostream>

using namespace std;

int A(unsigned int, unsigned int);

int main() {
	cout << "La fonction Ackermann pour 2 et 2 : " << A(2, 2) << endl;
	return 0;
}

int A(unsigned int m, unsigned int n) {
	if (m == 0)
		return n + 1;
	else if (m > 0 && n == 0)
		return A(m - 1, 1);
	else
		return A(m - 1, A(m, n - 1));
}