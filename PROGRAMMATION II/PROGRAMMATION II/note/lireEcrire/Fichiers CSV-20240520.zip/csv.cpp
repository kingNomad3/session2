#include "csv.h"
#include <iostream>
#include <fstream>

using namespace std;

void EcrireCSV(string nomFichier, Contact contacts[], size_t taille) {
	fstream Fichier(nomFichier, ios::out);

	for (size_t i = 0; i < taille; i++)
	{
		Contact C = contacts[i];
		Fichier << C.nom << "," << C.prenom << ","
			<< C.dateNaissance.jour << "," << C.dateNaissance.mois << ","
			<< C.dateNaissance.annee << "," << C.telephone;
		if (i < taille - 1)
			Fichier << "\n";
	}
	Fichier.close();
}

static string LireValeur(fstream& fichier) {
	string valeur = "";
	char C;
	while ((C = (char)fichier.get()) != ',' && C != '\n' && !fichier.eof())
		valeur += C;
	return valeur;
}

size_t LireCSV(std::string nomFichier, Contact contacts[], size_t taille) {
	fstream Fichier;// (nomFichier, ios::in);
	Fichier.open(nomFichier, ios::in);

	if (Fichier.fail()) {
		cout << "Le fichier n'a pas pu ouvrir";
		exit(EXIT_FAILURE);
	}

	size_t i;
	for (i = 0; i < taille && !Fichier.eof(); i++)
	{
		Contact contact;
		// R�cup�r� le nom
		contact.nom = LireValeur(Fichier);
		contact.prenom = LireValeur(Fichier);
		contact.dateNaissance.jour = stoi(LireValeur(Fichier));
		contact.dateNaissance.mois = stoi(LireValeur(Fichier));
		contact.dateNaissance.annee = stoi(LireValeur(Fichier));
		contact.telephone = stoll(LireValeur(Fichier));

		contacts[i] = contact;
	}

	Fichier.close();
	return i;
}

int main() {
	Contact contacts[] = {
		{"B", "G", {13, 12, 1919}, 42},
		{"T", "J", {14, 02, 1949}, 80}
	};

	EcrireCSV("contact.csv", contacts, 2);

	Contact contacts_lus[150];
	size_t nblu = LireCSV("contact.csv", contacts_lus, 150);

	for (size_t i = 0; i < nblu; i++)
	{
		cout << contacts_lus[i].nom << ", " << contacts_lus[i].prenom << "\n";
	}
}