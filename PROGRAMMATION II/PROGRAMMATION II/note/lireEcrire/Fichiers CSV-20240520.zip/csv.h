#pragma once
#include <string>

struct Date
{
	int jour, mois, annee;
};

struct Contact
{
	std::string nom, prenom;
	Date dateNaissance;
	long long telephone;
};

void EcrireCSV(std::string nomFichier, Contact contacts[], size_t taille);
size_t LireCSV(std::string nomFichier, Contact contacts[], size_t taille);
