#pragma once
#include "type.h"


Date_s Location(int, int);

float Retour(int, int, Date_s);
void RetourMain();
void LocationMain();