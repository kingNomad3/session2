#pragma once
#include "type.h"




void NouveauLivre();

Livre_s RechercherLivre(int);
void MiseAJourLivre(int, Livre_s);
void AfficherLivre(int);
void ListeDesLivresPretes();
