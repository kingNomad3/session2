#pragma once
#include "type.h"

#define NOM_ETUDIANT_E "Joinvil"
#define PRENOM_ETUDIANT_E "Benjamin"
#define MATRICULE "1662413"

extern std::string globalFileName;

void RunTest();