#pragma once
#include "type.h"



void NouveauClient();
Client_s RechercherDossierClient(int);
void AfficherDossierClient(int);
void MiseAJourClient(int, Client_s );
void ListeDesClientsEnRetard();
void NouveauClientMain();
void RechercherClientMain();